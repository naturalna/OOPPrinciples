﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AcademyPopcorn
{
    public class Shoot: Engine
    {
        public Shoot(IRenderer renderer,IUserInterface userInterface, int sleepTime): base(renderer,userInterface,sleepTime)
        {
        }
        public void ShootPlayerRacket()
        {
        }
    }
}
