﻿using System;

public interface ICalculatable
{
    void CalcInterest(sbyte period);   
}

