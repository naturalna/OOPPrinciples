﻿using System;

public interface IDrawable
{
    void Draw(decimal sum);
}

