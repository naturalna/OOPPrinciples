﻿using System;

public enum Custemer
{
    Individual,
    Companie,
}

