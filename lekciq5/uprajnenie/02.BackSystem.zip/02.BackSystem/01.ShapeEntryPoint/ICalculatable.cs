﻿using System;

public interface ICalculatable
{
    float CalculateSurface();
}

